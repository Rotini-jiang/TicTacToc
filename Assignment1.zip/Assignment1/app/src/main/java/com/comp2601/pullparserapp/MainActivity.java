package com.comp2601.pullparserapp;

/**
 * (c) 2019 L.D. Nel
 */
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.String;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String TAG =  MainActivity.class.getSimpleName();

    private Button mAButton;
    private Button mBButton;
    private Button mCButton;
    private Button mDButton;
    private Button mEButton;
    private Button mNextButton;
    private Button mPrevButton;
    private Button mSubmitButton;
    private EditText emailIntent;
    private EditText emailAddress;
    private EditText emailURI;
    private EditText Name;
    private EditText Number;

    private TextView mQuestionTextView;

    private ArrayList<Question> questions;
    ArrayList<Question> mQuestions;
    private  ArrayList<Character> answer = new ArrayList<Character>();


    private int questionIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //set and inflate UI to manage

        mAButton = (Button) findViewById(R.id.A);
        mBButton = (Button) findViewById(R.id.B);
        mCButton = (Button) findViewById(R.id.C);
        mDButton = (Button) findViewById(R.id.D);
        mEButton = (Button) findViewById(R.id.E);
        mPrevButton = (Button) findViewById(R.id.prev_button);
        mNextButton = (Button) findViewById(R.id.next_button);
        //mSubmitButton = (Button) findViewById(R.id.Submit);
        mQuestions = new ArrayList<Question>();
        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);
        mQuestionTextView.setTextColor(Color.BLUE);

        mAButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mAButton.setBackgroundColor(Color.RED);
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.rgb(214,215,215));
                answer.add(questionIndex,'A');
                Log.i(TAG,"A Button Pressed");

            }
        });
        mBButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.RED);
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.rgb(214,215,215));

                Log.i(TAG,"B Button Pressed");
                answer.add(questionIndex,'B');

            }
        });
        mCButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.RED);
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.rgb(214,215,215));

                Log.i(TAG,"C Button Pressed");
                answer.add(questionIndex,'C');


            }
        });
        mDButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.RED);
                mEButton.setBackgroundColor(Color.rgb(214,215,215));

                Log.i(TAG,"D Button Pressed");
                answer.add(questionIndex,'D');

            }
        });
        mEButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.RED);

                Log.i(TAG,"E Button Pressed");
                answer.add(questionIndex,'E');


            }
        });
        mPrevButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Log.i(TAG, "Prev Button Clicked");

                if(questionIndex > 0) questionIndex--;

                mQuestionTextView.setText("" + (questionIndex + 1) + ") " +
                        questions.get(questionIndex).toString());
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.rgb(214,215,215));

                if(answer.size()<= questionIndex){

                }
                else{
                    if(answer.get(questionIndex) == 'A')
                    mAButton.setBackgroundColor(Color.RED);
                    if (answer.get(questionIndex) == 'B')
                        mBButton.setBackgroundColor(Color.RED);
                    if (answer.get(questionIndex) == 'C')
                        mCButton.setBackgroundColor(Color.RED);
                    if (answer.get(questionIndex) == 'D')
                        mDButton.setBackgroundColor(Color.RED);
                    if (answer.get(questionIndex) == 'E')
                        mEButton.setBackgroundColor(Color.RED);
                }



                //for debugging
                Toast t = Toast.makeText(MainActivity.this, "Prev Button Clicked", Toast.LENGTH_SHORT);
                t.show();
            }

        });
        mNextButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Log.i(TAG, "Next Button Clicked");

                if(questionIndex < questions.size()-1) questionIndex++;

                mQuestionTextView.setText("" + (questionIndex + 1) + ") " +
                        questions.get(questionIndex).toString());
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.rgb(214,215,215));
                if(answer.size()<= questionIndex){

                }
                else{
                    if(answer.get(questionIndex) == 'A')
                        mAButton.setBackgroundColor(Color.RED);
                    if (answer.get(questionIndex) == 'B')
                        mBButton.setBackgroundColor(Color.RED);
                    if (answer.get(questionIndex) == 'C')
                        mCButton.setBackgroundColor(Color.RED);
                    if (answer.get(questionIndex) == 'D')
                        mDButton.setBackgroundColor(Color.RED);
                    if (answer.get(questionIndex) == 'E')
                        mEButton.setBackgroundColor(Color.RED);
                }

                //for debugging
                Toast t = Toast.makeText(MainActivity.this, "Next Button Clicked", Toast.LENGTH_SHORT);
                t.show();

            }

        });
        /*mSubmitButton.setOnClickListener((View v)->{
            Log.i(TAG, "Send Button Clicked");
            String emailBBody = Name.getText().toString();
            String emailAddress = Number.getText().toString();
            String emailURI = "mailto:" + emailAddress;
            //Intent enailIntent = new Intent(Intent.ACTION_SENDTO), Uri.parse(emailURI);
            //emailIntent.putExtra(Intent.EXTRA_TEXT, emailBBody);
            //startActivity(Intent,createChooser(emailIntent, "Email Client"));
        });*/

        //Initialise Data Model objects
        //questions = Question.exampleSet1();
        questions = null;
        questionIndex = 0;




        //Try to read resource data file with questions

        ArrayList<Question> parsedModel = null;
        try {
            InputStream iStream = getResources().openRawResource(R.raw.comp2601exam);
            BufferedReader bReader = new BufferedReader(new InputStreamReader(iStream));
            //ArrayList<Question> parsedModel = Exam.parseFrom(bs);
            parsedModel = Exam.pullParseFrom(bReader);
            bReader.close();
        }
        catch (java.io.IOException e){
            e.printStackTrace();

        }
        if(parsedModel == null || parsedModel.isEmpty())
            Log.i(TAG, "ERROR: Questions Not Parsed");
        questions = parsedModel;

        if(questions != null && questions.size() > 0)
            mQuestionTextView.setText("" + (questionIndex + 1) + ") " +
                    questions.get(questionIndex).toString());

    }

}
